import React from 'react';

export const SandwichPage = () => {
  return (
    <div className="container">
      <h1 className="display-6">Sandwiches</h1>
      <h3>This page is not a microfrontend</h3>
    </div>
  )
}