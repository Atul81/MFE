//these libraries would be shared accross the micro-frontend apps dont major upgrade the versions of these packages
require('react');
require('react-dom');
require('react-redux');
require('react-router');
require('redux');
