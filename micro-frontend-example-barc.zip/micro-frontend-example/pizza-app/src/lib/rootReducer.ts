import { combineReducers } from 'redux';

const RootReducer = combineReducers({
});

export default RootReducer;
