# pizza-app

This is the microfrontend app

## Getting Started

To launch locally and run the UI:

```
$ npm start
```

The UI will be available at http://localhost:8080.

Create a build using:

```
$ npm run build
```

The static files will be generated in ./dist

